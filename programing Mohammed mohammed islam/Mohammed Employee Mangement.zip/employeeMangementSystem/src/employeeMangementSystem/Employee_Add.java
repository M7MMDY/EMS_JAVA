package employeeMangementSystem;

import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

import employeeMangementSystem.Employee_Detail;

public class Employee_Add {
	 public void createFile()
	    {
	        Scanner sc=new Scanner(System.in);

	        Employee_Detail emp=new Employee_Detail();
	        emp.getInfo();
	        try{
	            File f1=new File("file"+emp.ID+".txt");
	            if(f1.createNewFile()){
	                FileWriter myWriter = new FileWriter("file"+emp.ID+".txt");
	                myWriter.write("Employee ID :"+emp.ID+"\n"+
	                "Employee First Name        :"+emp.First_Name+"\n"+
	                "Employee Last Name         :"+emp.Last_Name+"\n"+
	                "Employee Age               :"+emp.Age+"\n"+
	                "Employee Gender            :"+emp.Gender+"\n"+
	                "Employee Email             :"+emp.Email+"\n"+
	                "Employee Contact           :"+emp.contact+"\n"+
	                "Employee Date of Birth     :"+emp.Date_of_Birth+"\n"+
	                "Employee Position          :"+emp.Position+"\n"+
	                "Employee Department        :"+emp.Department+"\n"+
	                "Employee Salary            :"+emp.Salary);
	                myWriter.close();
	                System.out.println("\nEmployee has been Added Successfully\n");

	                System.out.print("\nPress Enter to Continue...");
	                sc.nextLine();
	            }
	            else {
	                System.out.println("\nEmployee already exists!");
	                System.out.print("\nPress Enter to Continue...");
	                sc.nextLine();
	            }
	        }
	        catch(Exception e){System.out.println(e);}
	    }

}
