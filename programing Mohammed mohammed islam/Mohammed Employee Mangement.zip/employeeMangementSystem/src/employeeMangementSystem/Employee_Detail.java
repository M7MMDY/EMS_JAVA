package employeeMangementSystem;

import java.util.Scanner;

public class Employee_Detail {
	    int ID;
	    String First_Name;
	    String Last_Name;
	    int Age;
	    String Gender;
	    String Email;
	    int contact;
	    String Date_of_Birth;
	    String Position;
	    String Department;
	    int Salary;
	    public void getInfo()
	    {
	        Scanner sc=new Scanner(System.in);
	        System.out.print("Enter Employee's  ID -: ");
	        ID=sc.nextInt();
	        System.out.print("Enter Employee's First name -: ");
	        First_Name=sc.next();
	        System.out.print("Enter Employee's Last name -: ");
	        Last_Name=sc.next();
	        System.out.print("Enter Employee's Age -: ");
	        Age=sc.nextInt();
	        System.out.print("Enter Employee's  Gender -: ");
	        Gender=sc.next();
	        System.out.print("Enter Employee's Email -: ");
	        Email=sc.next();
	        System.out.print("Enter Employee contact number -: ");
	        contact=sc.nextInt();
	        System.out.print("Enter Employee's  Date of Birth -: ");
	        Date_of_Birth=sc.next();
	        System.out.print("Enter Employee's Position -: ");
	        Position=sc.next();
	        System.out.print("Enter Employee's Department -: ");
	        Department=sc.next();
	        System.out.print("Enter Employee's Salary -: ");
	        Salary=sc.nextInt();
	    }


}
