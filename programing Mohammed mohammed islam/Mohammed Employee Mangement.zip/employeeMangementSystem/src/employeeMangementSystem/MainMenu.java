package employeeMangementSystem;

public class MainMenu {
	public void menu()
	  {
	    System.out.println("===========================================");
	    System.out.println("========EMPLOYEE MANAGEMENT SYSTEM=========");
	    System.out.println("===========================================");
	    System.out.println("-------------------------------------------");
	    System.out.println("------------- MOHAMMED --------------------");
	    System.out.println("-------------------------------------------");
	    System.out.println("\n\nPress 1 : To Add an Employee Details");
	    System.out.println("Press 2 : To See an Employee Details ");
	    System.out.println("Press 3 : To Remove an Employee");
	    System.out.println("Press 4 : To Update Employee Details");
	    System.out.println("Press 5 : To Exit the EMS Portal");

	  }

}
