package employeeMangementSystem;

public class CodeExit {
	public void out()
	  {
	    System.out.println("\n=======================================");
	    System.out.println(" Thank You For Using my Software  ");
	    System.out.println("=======================================");
	    System.exit(0);
	  }

}
