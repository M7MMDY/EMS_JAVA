package employeeMangementSystem;

import java.io.File;

public class Employee_Remove {
	public void removeFile(int ID){

    File file = new File("file"+ID+".txt");
      if(file.exists())
       {file.delete();
        System.out.println("\nEmployee has been removed Successfully");
         
       }
      else
       {
            System.out.println("\nEmployee does not exists :( ");
       }
     }

}
