package typesOfAlgorithms;

public class SelectionSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] arr = {59,94,87,61,72,82,98,68,49};
		int n = arr.length;
		

		System.out.println("\n Arry Befor Sorting ");
		for (int number : arr) {
			System.out.print(number+" ");
		}
		for (int i=0; i<n-1; i++) {
			int min = i;
			for (int j=i+1; j<n; j++) {
				if (arr[j] < arr[min])
				min = j;
			}
			int temp = arr[min];
			arr[min] = arr[i];
			arr[i] = temp;
		}
		System.out.print("\n"); 
		
		System.out.println("\n Arry After Sorting ");
		for (int number : arr) {
			System.out.print(number+" ");
		}
		
			System.out.print("\n"); 
	
		System.out.println("\n lowest  Score is "+(arr[0]));

		System.out.println("\n Highest  Score is "+(arr[8]));

	}

}
