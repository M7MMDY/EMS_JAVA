package typesOfAlgorithms;

import java.util.Scanner;

public class LinearSaerch {

	public static void main(String[] args) {
		try( // TODO Auto-generated method stub
		
		Scanner scanner = new Scanner (System.in)) {
			// Ask about the size of the array
			System.out.println("Enter the size of array");
			int n = scanner.nextInt(); // the size of the array 
			
			// Ask about the key element 
			System.out.print("Enter the key element");
			int x = scanner.nextInt();
			
			//Ask about the array 
			int[] arr = new int[n];
			
			for(int i = 0;i<n;i++) {
				System.out.println("Enter number "+(i+1)+":");
				arr[i]=scanner.nextInt();
			}
			
			boolean exist = false;
			
			for(int i=0; i<arr.length; i++) {
				if(arr[i]==x) {
					System.out.println("Exist");
					exist = true;
				}
			}
			
			if (!exist) {
				System.out.println("Not Exist");
			}
		}

	}

}
