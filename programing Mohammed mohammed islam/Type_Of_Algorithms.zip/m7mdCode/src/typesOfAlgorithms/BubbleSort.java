package typesOfAlgorithms;
 
public class BubbleSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {10,4,1,7,3,8,5};
		int n = arr.length;
		boolean swapped = false;
		
		System.out.print("\n UnSorted Arry \n ");
		for (int number : arr) {
			System.out.print(number+"  ") ;
		}
		
		for (int i=0; i<n-1; i++) {
			for(int j=0; j<n-i-1; j++) {
				if(arr[j]>arr[j+1]) {
					int temp = arr[j];
					arr[j] = arr[j+1];
					arr[j+1] = temp;
					swapped = true;
					
				}
			}
			if(!swapped) {
				break;
			}
			
		}
		System.out.print("\n Sorted Arry \n ");
		for (int number : arr) {
			System.out.print(number+"  ");
		}

	}

}
