package m7mdCode;

public class Round1 {
	public static void BubbleSort(int[] arr) {
		//body of Bubble Sort
		
		int n = arr.length;
		boolean swapped = false;
		
		System.out.print("\n UnSorted Arry \n ");
		for (int number : arr) {
			System.out.print(number+"  ") ;
		}
		
		for (int i=0; i<n-1; i++) {
			for(int j=0; j<n-i-1; j++) {
				if(arr[j]>arr[j+1]) {
					int temp = arr[j];
					arr[j] = arr[j+1];
					arr[j+1] = temp;
					swapped = true;
					
				}
			}
			if(!swapped) {
				break;
			}
			
		}
		System.out.print("\n Sorted Arry \n ");
		for (int number : arr) {
			System.out.print(number+"  ");
		}
		System.out.println("\n \n");

	}
	
	public static void SelectioSort(int[] arr) {
				int n = arr.length;
		

		System.out.print(" \n Arry Befor Sorting \n ");
		for (int number : arr) {
			System.out.print(number+"  ");
		}
		for (int i=0; i<n-1; i++) {
			int min = i;
			for (int j=i+1; j<n; j++) {
				if (arr[j] < arr[min])
				min = j;
			}
			int temp = arr[min];
			arr[min] = arr[i];
			arr[i] = temp;
		} 
		
		System.out.print(" \n Arry After Sorting \n ");
		for (int number : arr) {
			System.out.print(number+"  ");
		}
		System.out.print("\n");
		System.out.println("\n lowest  Score is "+(arr[0]));

		System.out.println(" Highest  Score is "+(arr[8]));
		System.out.print("\n"); 
	}

	public static void LinearSaerch(int[] arr, int x) {
		
			int n = arr.length; // the size of the array 
			
			boolean exist = false;
			
			for(int i=0; i<n; i++) {
				if(arr[i]==x) {
					System.out.print("\n");
					
					System.out.println(" Exist");
					exist = true;
				}
			}
			
			if (!exist) {
				System.out.println("\n"); 
				
				System.out.println(" Not Exist");
			}
		}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] patientsID = {101,111,104,117,103,108,105};
		BubbleSort(patientsID);
		
		int [] ExamsScore = {59,94,87,61,72,82,98,68,49};
		SelectioSort(ExamsScore);
		
		int [] array = {4,7,1,9,5};
		int x = 10;
		LinearSaerch(array, x);


	}

}

